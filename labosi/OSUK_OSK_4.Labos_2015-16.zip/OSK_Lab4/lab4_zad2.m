clc
close all
clear all
colordef none

%% generiranje signala uRX
tmax = 50e-6;
fs = 200e6;
% vremenska os za analognu domenu
t=(0:1/fs:tmax);
t=t(:);
% komunikacijski kanal
fRF=50e6;   % centralna radio frekvencija
BRF=2e6;    % sirina radio podrucja
% radio signal
uRX = sinc(8*pi*BRF*(t - tmax/4)) .* square(2*pi*fRF*t);
fsH = 20e6;

plot (t, uRX), title ('uRX'),
xlabel ('t[s]'), ylabel ('uRX');

%%
N = length(t);
p = blackman(N)';
Nfft = 2*N;
f = fos(Nfft, fs);
URX = 1/sum(p) .* fftshift (fft (uRX.*p', Nfft));
figure,
plot (f, 20*log10(abs(URX))), title ('Spektar URX'),
xlabel ('f[Hz]'), ylabel ('URX');


%% signal oscilatora
fOSC = 45e6;
uOSC = cos(2*pi*fOSC*t);

%% 

%RF filtar -- trebalo bu promijeniti red filtra

[Z, P, K] = cheby1(3, 0.5, (2*pi) * [49e6 51e6], 's');   %model opisan polovima, nulama i pojacanjem, 's' jer se radi o analognom modelu
HRF = freqs(K .* poly(Z), poly(P), f*2*pi);

figure();
plot(f, 20*log10(abs(HRF))), title('Frekvencijska karakteristika RF filtra');  %20*log10()
SYS_HRF = zpk(Z, P, K);
hRF = impulse(SYS_HRF, t);

%IF filtar
fsH = 20e6;
[Z, P, K] = ellip(6, 0.5, 80, 2 * pi * fsH/2, 's');
HIF = freqs(K .* poly(Z), poly(P), 2 * pi * f);

figure();
plot(f, 20*log10(abs(HIF))), title('Frekvencijska karakteristika IF filtra');
SYS_HIF = zpk(Z, P, K);
hIF = impulse(SYS_HIF, t);

%% konvolucija
amp = 10;
uRF = 1/fs * conv(uRX, hRF) * amp;
uRF = uRF(1:N);
uRF = uRF .* uOSC;
uIF = 1/fs * conv(uRF, hIF) * amp;
uIF = uIF(1:N);

figure();
URF = 1/sum(p) .* fftshift (fft (uRF.*p', Nfft));
plot(f, 20*log10(abs(URF))), title('Spektar URF');

figure();
UIF = 1/sum(p) .* fftshift (fft (uIF.*p', Nfft));
plot(f, 20*log10(abs(UIF))), title('Spektar UIF');

figure();
plot(f, 20*log10(abs(URX)), f, 20*log10(abs(URF)), f, 20*log10(abs(UIF))), title('Spektar compilation');
XLIM([0 10^8])
%% AD pretvornik

%tH = 0:1/fsH:tmax;
tH = t(1:fs/fsH:end);
N2 = length(tH);
NH = N2;
Nfft2 = 2*N2;
fH = fos(Nfft2, fsH);
%uAD = fsH * decimate(uIF, ceil(length(t)/length(tH)));
uAD = uIF(1:fs/fsH:end);
figure();
plot(tH, uAD), title('uAD');

p2 = blackman(N2)';
UAD = 1/sum(p2) .* fftshift (fft (uAD.*p2', Nfft2));
figure();
plot (fH, 20*log10(abs(UAD))), title ('Spektar UAD'),
xlabel ('f[Hz]'), ylabel ('UAD');

%% Drugi zadatak
% NCO
wNCO = 2*pi*5e6/fsH;

n = tH .* fsH;
uNCO = uAD .* exp(1i*wNCO*n);

p2 = blackman(N2)';
UNCO = 1/sum(p2) .* fftshift (fft (uNCO.*p2', Nfft2));

figure();
plot (fH, 20*log10(abs(UNCO))), title ('Spektar UNCO'),
xlabel ('f[Hz]'), ylabel ('UNCO');

%% CIC
fsL = 2e6;
R = fsH/fsL;

tL = tH(1:R:end);
NL = length(tL);
NLfft = 2*NL;
fL = fos(NLfft, fsL);
pL = blackman(NL)';

hCIC1 = 1/R * ones(1, R);
hCIC=1;
red=6;
for n=1:red
  hCIC=conv(hCIC,hCIC1) 
end

HCICH = freqz(hCIC, 1, fos(NLfft, 2*pi));
HCICL = freqz(hCIC, 1, fos(NLfft, 2*pi)/R);

figure();
plot (fL, 20*log10(abs(HCICH))), title ('Frekvencijska karakteristika HCICH'),
xlabel ('f[Hz]'), ylabel ('HCICH');

figure();
plot (fL, 20*log10(abs(HCICL))), title ('Frekvencijska karakteristika HCICL'),
xlabel ('f[Hz]'), ylabel ('HCICL');

uCIC = conv(hCIC, uNCO);
uCIC = uCIC(1:R:NH);

% UCIC = 1/sum(pL) .* fftshift (fft (uCIC.*pL', NLfft));
%  
% figure();
% plot (fL, 20*log10(abs(UCIC))), title ('Spektar UCIC'),
% xlabel ('f[Hz]'), ylabel ('UCIC');

%% kompenzator
Apass_dB = 0.1;
Astop_dB = 40;
Apass = 1 -10^((-Apass_dB/2)/20);
Astop = 10^((-Astop_dB)/20);
Red_Kompenzatora = 60;
B = 500e3;

hCICK=firceqrip(Red_Kompenzatora,... % red FIR filtra
B/fsL/2*2*pi,... % granica propustanja ili gusenja
[Apass, Astop],... % maksimalna apsolutna odstupanja
'invsinc', [0.5, red],... % aproksimira se [aw/sin(aw)]^N
'passedge'... % wg odreduje podrucje propustanja
);

HCICK = freqz(hCICK, 1, fos(NLfft, 2*pi));
figure();
plot (fL, 20*log10(abs(HCICK))), title ('Frekvencijska karakteristika HCICK'),
xlabel ('f[Hz]'), ylabel ('HCICK');

%% channel filter

red_filtra = 300;
hcfir = cfirpm(red_filtra - 1, [-fsL/2 0 - 0.05*B 0 B 1.05*B fsL/2]./(fsL/2), [0 0 2 2 0 0]);
HCFIR = freqz(hcfir, 1, 2*pi*fL/(fsL));
figure();
plot (fL, 20*log10(abs(HCFIR))), title ('Frekvencijska karakteristika HCFIR'),
xlabel ('f[Hz]'), ylabel ('HCFIR');

uCICK = conv(uCIC, hCICK);
uCICK = uCICK(1:NL);
uCF_re = conv(real(uCICK), real(hcfir), 'same');
uCF_im = conv(imag(uCICK), imag(hcfir), 'same');

uCF = uCF_re + uCF_im;

UCF = 1/sum(pL) .* fftshift (fft (uCF.*pL', NLfft));
figure();
plot (fL, 20*log10(abs(UCF))), title ('Spektar UCIC'),
xlabel ('f[Hz]'), ylabel ('UCF');


% DA
ui=interp(uCF,R);
ui=ui(1:end-R+1);

figure
plot(tL, uCF,'r',tH, ui,'y');







