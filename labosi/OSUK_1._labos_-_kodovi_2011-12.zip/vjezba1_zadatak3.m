close all
clear all
colordef none

Fs = 10;
N = 101;
n = (-(N-1)/2:1:(N-1)/2)*1/Fs;
x = exp(-n.^2)+1i*(1-cos(10*n))./n.*exp(-abs(n));
x(n==0)=1;

f1 = fos(N, Fs);
X = fftshift(fft(x,N))/N;
figure;
stem(f1, abs(X));
figure;

figure;
stem(n, abs(x));

Ex=sum(1/Fs*abs(x).^2)

f2 = fos(5*N, Fs);
X2 = fftshift(fft(x,5*N))/N;

figure;
stem(f2, abs(X2));

%M = 50;
%f2 = fos(M, Fs);

%m = -0.25:0.01:0.25-0.01;
%x2 = exp(j*20*pi*m);
%X2 = fftshift(fft(x2))/M;
%figure;
%stem(f2, (abs(X2)));