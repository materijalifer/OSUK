close all
clear all
colordef none

N = 80;
n = 0:1:(N-1);
x = square(0.1*pi*n);

figure;
stem(n,x);

% ra�unanje hilberta ru�no

X = fft(x,N);
X = [X(1),2*X(2:ceil(N/2)),zeros(1,floor(N/2))];
z = ifft(X,N);

figure;
stem(n,imag(z)); % xh je analiti�ki, hilbert je samo imaginarni dio

% ra�unanje hilberta funkcijom

z = hilbert(x)
figure;
stem(n,imag(z));

% pro�irivanje nulama

xp = [x,zeros(1,10)]; % 10 nula
zp = hilbert(xp);
z = zp(1:length(x));
figure;
plot(n, imag(z));

xp = [x,zeros(1,10)]; % 1000 nula
zp = hilbert(xp);
z = zp(1:length(x));
figure;
plot(n, imag(z));
