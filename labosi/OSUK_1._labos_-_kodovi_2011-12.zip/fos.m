function f=fos(N,fs)
deltaf=fs/N;

if 2*floor(N/2)==N
    f=linspace(-fs/2,fs/2-deltaf,N);
else
    f=linspace(-(fs-deltaf)/2,(fs-deltaf)/2,N);
end