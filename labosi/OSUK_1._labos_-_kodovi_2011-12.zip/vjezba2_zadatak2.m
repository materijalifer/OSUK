close all
clear all
colordef none

N = 401;
n = -(N-1)/2:1:(N-1)/2;
x = 0.6*sinc(0.6*n)-0.2*sinc(0.2*n);

hHT = firpm(99,[0.1,1],[1,1],'Hilbert'); % koristi tip4
hLK = firpm(99,[0.1,1],[1,1]); % linija za ka�njenje

w = linspace(-pi,pi,1000);
HHT = freqz(hHT,1,w);
GHT = 20*log10(abs(HHT));
figure;
plot(w,GHT);

HLK = freqz(hLK,1,w);
GLK = 20*log10(abs(HLK));
figure;
plot(w,GLK);
