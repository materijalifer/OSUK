close all
clear all
colordef none

Fs = 100;
N = 51;
f1 = fos(N, Fs);
n = -0.25:0.01:0.25;
x = exp(j*20*pi*n);
xr = real(x);
xim = imag(x);
subplot(211), stem(n, xr);
subplot(212), stem(n, xim);

X = fftshift(fft(x))/N;
figure;
stem(f1, (abs(X)));
figure;
stem(f1, angle(X));

M = 50;
f2 = fos(M, Fs);
m = -0.25:0.01:0.25-0.01;
x2 = exp(j*20*pi*m);
X2 = fftshift(fft(x2))/M;
figure;
stem(f2, (abs(X2)));