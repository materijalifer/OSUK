close all
clear all
colordef none

N=80;
n = 0:1:(N-1);
x = square(0.1*pi*n);

figure;
plot(n,x);


z = hilbert(x);


plot(n,imag(z));
figure;
stem(n,imag(z));

%dodavanje nula

xp=[x,zeros(1,10)];
z1 = hilbert(xp);
z11 = z1(1:length(x));

xc=[x,zeros(1,1000)];
z2 = hilbert(xc);
z22 = z2(1:length(x));

figure;
plot(n, x);
hold on;
plot(n, imag(z));
hold on;

figure;
plot(n,imag(z11));
hold on;
plot(n, imag(z22));
hold on;