close all
clear all
colordef none

tmax = 1200;
[x, t] = izvor01(tmax);

Fs = 100e3;
f = fos(length(x), Fs);

X = fftshift(fft(x))/length(x);

%k=0:length(x)-1;
%wk=2*pi*k/length(x);
figure;
plot(f, 20*log10(abs(X)));