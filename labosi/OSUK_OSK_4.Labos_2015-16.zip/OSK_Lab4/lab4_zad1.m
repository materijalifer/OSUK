clc
close all
clear all
colordef none

%% generiranje signala uRX
tmax = 50e-6;
fs = 200e6;
% vremenska os za analognu domenu
t=(0:1/fs:tmax);
t=t(:);
% komunikacijski kanal
fRF=50e6;   % centralna radio frekvencija
BRF=2e6;    % sirina radio podrucja
% radio signal
uRX = sinc(8*pi*BRF*(t - tmax/4)) .* square(2*pi*fRF*t);
fsH = 20e6;

plot (t, uRX), title ('uRX'),
xlabel ('t[s]'), ylabel ('uRX');

%%
N = length(t);
p = blackman(N)';
Nfft = 2*N;
f = fos(Nfft, fs);
URX = 1/sum(p) .* fftshift (fft (uRX.*p', Nfft));
figure,
plot (f, 20*log10(abs(URX))), title ('Spektar URX'),
xlabel ('f[Hz]'), ylabel ('URX');


%% signal oscilatora
fOSC = 45e6;
uOSC = cos(2*pi*fOSC*t);

%% 

%RF filtar -- trebalo bu promijeniti red filtra

[Z, P, K] = cheby1(3, 0.5, (2*pi) * [49e6 51e6], 's');   %model opisan polovima, nulama i pojacanjem, 's' jer se radi o analognom modelu
HRF = freqs(K .* poly(Z), poly(P), f*2*pi);

figure();
plot(f, 20*log10(abs(HRF))), title('Frekvencijska karakteristika RF filtra');  %20*log10()
SYS_HRF = zpk(Z, P, K);
hRF = impulse(SYS_HRF, t);

%IF filtar
fsH = 20e6;
[Z, P, K] = ellip(6, 0.5, 80, 2 * pi * fsH/2, 's');
HIF = freqs(K .* poly(Z), poly(P), 2 * pi * f);

figure();
plot(f, 20*log10(abs(HIF))), title('Frekvencijska karakteristika IF filtra');
SYS_HIF = zpk(Z, P, K);
hIF = impulse(SYS_HIF, t);

%% konvolucija
amp = 10;
uRF = 1/fs * conv(uRX, hRF) * amp;
uRF = uRF(1:N);
uRF = uRF .* uOSC;
uIF = 1/fs * conv(uRF, hIF) * amp;
uIF = uIF(1:N);

figure();
URF = 1/sum(p) .* fftshift (fft (uRF.*p', Nfft));
plot(f, 20*log10(abs(URF))), title('Spektar URF');

figure();
UIF = 1/sum(p) .* fftshift (fft (uIF.*p', Nfft));
plot(f, 20*log10(abs(UIF))), title('Spektar UIF');

figure();
plot(f, 20*log10(abs(URX)), f, 20*log10(abs(URF)), f, 20*log10(abs(UIF))), title('Spektar compilation');
XLIM([0 10^8])
%% AD pretvornik

%tH = 0:1/fsH:tmax;
tH = t(1:fs/fsH:end);
N2 = length(tH);
Nfft2 = 2*N2;
fH = fos(Nfft2, fsH);
%uAD = fsH * decimate(uIF, ceil(length(t)/length(tH)));
uAD = uIF(1:fs/fsH:end);
figure();
plot(tH, uAD), title('uAD');

p2 = blackman(N2)';
UAD = 1/sum(p2) .* fftshift (fft (uAD.*p2', Nfft2));
figure();
plot (fH, 20*log10(abs(UAD))), title ('Spektar UAD'),
xlabel ('f[Hz]'), ylabel ('UAD');





