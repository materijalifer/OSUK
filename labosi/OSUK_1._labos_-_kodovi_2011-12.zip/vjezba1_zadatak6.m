close all
clear all
colordef none

N = 401;
n = -(N-1)/2:1:(N-1)/2;
x = 0.6*sinc(0.6*n)-0.2*sinc(0.2*n);

plot (n,x);

f = fos(N, 1);
X = fftshift(fft(x,N));
figure;
plot(f, abs(X));

hHT = cfirpm(99,[-1,0.1,0.2,0.6,0.7,1],[0,0,1,1,0,0]); % koristi tip4


w=2*pi*f;
HHT = freqz(hHT,1,w);
figure;
plot(w,20*log10(abs(HHT)));

%HDL = freqz(hDL,1,w);
%figure;
%plot(w,20*log10(abs(HDL)));


%yDL=conv(x,hDL);
%yDL=yDL(1:length(x));
yHT=conv(x,hHT);
yHT=yHT(1:length(x));

%figure;
%plot (w,yDL,'r');
figure;
Y = fftshift(fft(yHT,N));
plot(w,abs(Y),'y');

%figure;
%y=x+j*yHT;
%Y = fftshift(fft(y,N));
%plot(w,abs(Y));

%figure;
%HF=+j*hHT;
%HFn= freqz(HF,1,w);
%plot (w,20*log10(abs(HFn)));
